tiledMatrix
===========

TiledMatrix was designed to support the development of applications that require the manipulation of huge matrices in external memory. And, as is known, any application requiring external memory processing should be designed focusing the I/O operations reduction.
