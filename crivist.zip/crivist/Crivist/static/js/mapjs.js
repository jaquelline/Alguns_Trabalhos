var csData;
var EdgeList;
var marker;
var CrimeList       = []
var center          = [];
const dateFmt       = d3.timeParse("%d-%m-%Y %H:%M:%S");
var MAP             = {};
var polylines       = [];
const colorScale    = ['#ffeda0', '#f03b20'];
//var SliceBarDiv     =  document.getElementById("slider").style.display;

//

function showRadius(){
    document.getElementById("secondSlider").style.display='block';
}
function hideRadius(){
    document.getElementById("secondSlider").style.display='none';
}
hideRadius(); 


//document.getElementById("fatterDiv").disabled = true;
//SliceBarDiv.disabled=true;

//$( "#chart" ).prop( "disabled", true ); //Disable

const colorPalette = { 0.0: colorScale[0], 1.0: colorScale[1] }
const heightPalette = 100;
var cdblight = L.tileLayer('https://cartodb-basemaps-{s}.global.ssl.fastly.net/light_all/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="http://cartodb.com/attributions">CartoDB</a>',
            subdomains: 'abcd',
            minZoom: 0,
            maxZoom: 22,
            maxNativeZoom: 18,
		});

const map = new L.Map('map', {
    		layers: [cdblight], //[Hydda_Full],//[CartoDB_Positron],
            center: new L.LatLng(-23.548682, -46.634731), //centro do Sao Paulo
    		zoom: 13,
    		worldCopyJump: false,
    		zoomControl: false,
    		pitch: 80
    	   });
    
L.control.zoom({ position: 'bottomright' }).addTo(map);
cdblight.addTo(map);

// Initialise the FeatureGroup to store editable layers
var drawnItems = new L.FeatureGroup();
map.addLayer(drawnItems);


var stateChangingButton = L.easyButton({ position: 'bottomright',
    states: [{
           
            stateName: 'Refresh Map',        // name the state
            icon:      'glyphicon glyphicon-refresh',               // and define its properties
            title:     'Refresh Map',      // like its title
            onClick: function(btn, map) {       // and its callback
                window.location.reload();
            },
        } ]        
});

var stateChangingButton = L.easyButton({
    states: [{
            stateName: 'Tutorial to Selection',        // name the state
            icon:      'glyphicon glyphicon-facetime-video',               // and define its properties
            title:     'Tutorial to Selection',      // like its title
            onClick: function(btn, map) {       // and its callback
               $("#myModal").modal();
            },
        } ]        
});
stateChangingButton.addTo(map)



var drawPluginOptions = {
  position: 'bottomright',
  draw: {
	polyline: false,//true,
	marker: true,
	circle: false,
	rectangle: false,
	circlemarker: false,
	polygon: true,
	editable: false,
	},
  //edit: {
  //    featureGroup: drawnItems, //REQUIRED!!
   //   remove: false,
     // buffer: {replacePolylines: false,
      //separateBuffer: false}
  //}
};

// Initialise the draw control and pass it the FeatureGroup of editable layers
var drawControl = new L.Control.Draw(drawPluginOptions);
map.addControl(drawControl);
stateChangingButton.addTo(map);
//var drawnItems = new L.FeatureGroup();
//map.addLayer(drawnItems);
map.on('draw:drawstart', (e) => {
    var type = e.layerType;
    deleteElementsOfMap();
});
/*
map.on('draw:edited', function(e) {
    console.log("Edited: ",e);
    //Interior_Created_Edited(e);
}); */

map.on('draw:created', function(e) {
    Interior_Created_Edited(e);
});

function Interior_Created_Edited(e){
    hideRadius();
    var type = e.layerType,
    layer = e.layer;
	CrimeList = [];
    EdgeList = null;
    deleteGraph();
    if (csData != null) {
        //d3.selectAll("svg").remove();
        //d3.select("#temporalChartLine").selectAll("svg").remove();
        d3.select("#ChartBar").selectAll("svg").remove();
        d3.select("#temporalChartLine").selectAll("svg").remove();
    }
    if(marker != undefined){
        drawnItems.removeLayer(marker)
    }  

    if(type=='marker'){
        showRadius();
        var center = layer._latlng;
        
        latitude   = center.lat;
        longitude  = center.lng;

        CircleAjax(center,radiusCircle);
        //map.removeLayer(e.layer);

        /*marker=e;
        map.removeLayer(e.layer);
        //QueryWithMarker(e.layer._latlng.lat,e.layer._latlng.lng);
        var points = layer._latlngs;
        var lats = [],
            lngs = [];
        points[0].forEach(function(f) {
            lats.push(f.lat);
            lngs.push(f.lng);
        });

        MainAjax(lats,lngs)*/

           
        marker = layer;
     }
    
     drawnItems.addLayer(layer);
    
    //deleteElementsOfMap();
    if (e.layerType === 'polygon') {
        hideRadius();
        var points = layer._latlngs;
        var lats = [],
            lngs = [];
        points[0].forEach(function(f) {
            lats.push(f.lat);
            lngs.push(f.lng);
        });

        MainAjax(lats,lngs)
    }
}
function ChangingRadius(){

    CrimeList = [];
    EdgeList = null;
    deleteGraph();
    if (csData != null) {
        //d3.selectAll("svg").remove();
        d3.select("#ChartBar").selectAll("svg").remove();
        d3.select("#temporalChartLine").selectAll("svg").remove();

    }
    
    CircleAjax({'lat':latitude,'lng':longitude},radiusCircle);
}

function CircleAjax(center,radius){
    map.spin(true);
    $.ajax({
        url: '/Preprocessing_Graph_Circle_Crime_EC_T_V/',
        data: { 'lat': center.lat, 'lng': center.lng,'radius':radius },
        type: 'get',
        datatype: 'json',
        success: function(json) {
            //console.log(json);
            if(json.error != undefined){
                showError(json.error);
            }else{
                InteriorAjax(json);
            }
            map.spin(false);
        },
    }); 
}
function MainAjax(lats,lngs){
    map.spin(true);
    $.ajax({
        url: '/Preprocessing_Graph_Crime_EC_T_V/',
        data: { 'lats': JSON.stringify(lats), 'lngs': JSON.stringify(lngs) },
        type: 'get',
        datatype: 'json',
        success: function(json) {
            console.log(json);
            if(json.error != undefined){
                showError(json.error);
            }else{
                InteriorAjax(json);
            }
            //InteriorAjax(json);
            map.spin(false);
        },
    }); 
}

function InteriorAjax(json){

        EdgeList = json.EdgeList;
        CrimeList = json.Crimes;
        //console.log(EdgeList);
        
        //______________________________TESTE DE PLOT
        /*console.log(CrimeList);
        CrimeList.forEach(d => {
            L.circle([d.coord_y,d.coord_x], { color: 'green',  fillColor: '#f03', fillOpacity: 0.5, radius:2}).addTo(map);
        }); */
        //___________________________FIN TESTE DE PLOT


        main_Crossfilter();
        clearMap();
        render_Charts();
        /*CrimeList.forEach(d => {
            L.circle([d.coord_y,d.coord_x], { color: 'red',  fillColor: '#f03', fillOpacity: 0.5, radius: 10}).addTo(map);
        });*/
}

function showError(error){
    $('#alertid').show('fade').html(error +'<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span>  </button>');
}
function HideError(){
    $("#alertid").hide('fade');
}

map.on('draw:bufferstart', (e) => {
  for(i in map._layers) {
    if(map._layers[i]._path != undefined) {
        map._layers[i].setStyle({opacity:0.5,fillOpacity:0.2});
    }
}
});
map.on('draw:buffered', (e) => { //modify the style of map layers
      hideRadius();
      codSetorList   = [];
      var lats             = [],
          longs            = [],
          points           = [];
      /*---------------------------------------*/
      let temp=e.layers.getLayers();

      bufferedPolygon=temp[temp.length-1]._latlngs;
      let poly2  = temp[temp.length-1]._latlngs,
      bound  = temp[temp.length-1].getBounds(),
      latlng = bound.getCenter();
      poly2[0].forEach(function(d){
        points.push({x:parseFloat(d.lat),y:parseFloat(d.lng)});
        });
      Simple=simplify(points,0.0001); //reduce number of poinys
      //for (var i = 0; i < points.length; i++) {
      for (var i = 0; i < Simple.length; i++) {
        lats.push(Simple[i].x);longs.push(Simple[i].y);
      //lats.push(points[i].x); longs.push(points[i].y);
      }

      map.spin(true);
      
      $.ajax({

          url: '/Preprocessing_Graph_Crime_EC_T_V/',
          data: { 'lats': JSON.stringify(lats), 'lngs': JSON.stringify(longs) },
          type: 'get',
          datatype: 'json',
          success: function(json) {
              console.log(json);
              EdgeList = json.EdgeList;
              CrimeList = json.Crimes;
              main_Crossfilter();
              clearMap();

              render_Charts();

              map.spin(false);
          },
      }); 

});

function testeMYFUNCTION() {
	 map.spin(true);
     EdgeList = json.EdgeList;
     CrimeList = json.Crimes;
     main_Crossfilter();
     clearMap();

     render_Charts();

     map.spin(false);
}

// Insertando una leyenda en el mapa

var legend = L.control({ position: 'bottomright' });
/*---------------------------------------------- SEARCH CONTROL ------------------------------------*/
const provider= new window.GeoSearch.GoogleProvider({params: { key: 'AIzaSyD99K1qKrAxnMB66bLS1UHm6JJ7lkJ5Cy0', } });

/*
provider.GetLocations( addressText, function ( data ) {
  // in data are your results with x, y, label and bounds (currently availabel for google maps provider only)
});*/

const searchControl = new window.GeoSearch.GeoSearchControl({ provider: provider,                                                               
                                                              style: 'bar',
                                                              autoComplete: true,             // optional: true|false  - default true
                                                              autoCompleteDelay: 250,
                                                              showMarker: true,                                   // optional: true|false  - default true
                                                              showPopup: false,  
                                                              marker: {                                           // optional: L.Marker    - default L.Icon.Default
                                                                icon: new L.Icon.Default(),
                                                                draggable: true,
                                                              },   // optional: true|false  - default false
                                                              autoClose: true,                                   // optional: true|false  - default false
                                                              searchLabel: 'Enter address',                       // optional: string      - default 'Enter address'
                                                              keepResult: false,                                   // optional: true|false  - default false
                                                              animateZoom: true,
                                                              keepResult: true
                                                              });
 map.on('geosearch/results', function(data){
    /*results.clearLayers();
    for (var i = data.results.length - 1; i >= 0; i--) {
      results.addLayer(L.marker(data.results[i].latlng));
    }*/
  });

map.on('geosearch/showlocation', function(e){
      showRadius();
      deleteElementsOfMap();
    
      if(marker != undefined){
        drawnItems.removeLayer(marker)
      }      
      marker = e.layer;

      //marker=L.circleMarker([e.location.y,e.location.x],{color: 'red',radius:10});
      //marker.addTo(map);

      center={'lat':e.location.y,'lng':e.location.x}
      
      latitude   = center.lat;
      longitude  = center.lng;

    CrimeList = [];
    EdgeList = null;
    deleteGraph();
    if (csData != null) {
        //d3.selectAll("svg").remove();
        d3.select("#ChartBar").selectAll("svg").remove();
        d3.select("#temporalChartLine").selectAll("svg").remove();

    }
    CircleAjax(center,radiusCircle);
});
map.addControl(searchControl);
/*---------------------------------------------- SEARCH CONTROL ------------------------------------*/
/*
var center =layer._latlng;
        var radius =1500;
        CircleAjax(center,radius);
        map.removeLayer(e.layer);*/

/*----------------- UTILITIES FOR MAP */
function clearMap() {
    for (i in map._layers) {
        if (map._layers[i]._path != undefined) {
            map._layers[i].setStyle({ opacity: 0, fillOpacity: 0 });
        }
    }   
}

function deleteGraph() {
    polylines.forEach(function(d) {
        map.removeLayer(d);
    });
    polylines = []; 
}

function deleteElementsOfMap() {
  
    for (i in map._layers) {
        if (map._layers[i]._path != undefined) {
            try {
                map.removeLayer(map._layers[i]);
            } catch (e) {
                console.log("problem with " + e + map._layers[i]);
            }
        }
    }
    
}




