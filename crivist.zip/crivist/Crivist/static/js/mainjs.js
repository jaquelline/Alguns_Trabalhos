var MonthLabels  = ['Jan', 'Fev', 'Mar', 'Abr',  'Mai',  'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];// ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
var DayLabels    = ['Seg','Ter','Qua','Qui','Sex','Sab','Dom'];//["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
var PeriodLabels = ['Ama','Tar','Noi','Mad'];//["Mor","Aft","Eve",'Dawn'];

function snap_to_zero(source_group) {
    return {
        all:function () {
            return source_group.all().map(function(d) {
                return {key: d.key, 
                        value: ((d.value)<0) ? 0 : d.value};
            });
        }
    };
}

function main_Crossfilter() {
    csData = crossfilter(CrimeList);

    csData.dimCrimeType     = csData.dimension(function(d) { return d["crimeType"]; });
    csData.dimTime          = csData.dimension(function(d) { return dateFmt(d["date"]); });
    csData.dimNode          = csData.dimension(function(d) { return d["codnode"]; });

    //dimensiones labels
    csData.dimlabelMonth	= csData.dimension(function (d) { return d["labelMonth"]; });
    csData.dimlabelDay	    = csData.dimension(function (d) { return d["labelDay"]; });
    csData.dimlabelPeriod	= csData.dimension(function (d) { return d["labelPeriod"]; });
    


    csData.CrimeTypes       = csData.dimCrimeType.group();
    csData.time             = csData.dimTime.group(d3.timeMonth);
    csData.GroupNodes       = csData.dimNode.group();

    csData.labelMonth 		= csData.dimlabelMonth.group();
    csData.labelDay 		= csData.dimlabelDay.group();
    csData.labelPeriod 		= csData.dimlabelPeriod.group();

    //sort
    csData.labelMonth.all().sort(function(a,b){return MonthLabels.indexOf(a.key)-MonthLabels.indexOf(b.key);});
    csData.labelDay.all().sort(function(a,b){return DayLabels.indexOf(a.key)-DayLabels.indexOf(b.key);});
    csData.labelPeriod.all().sort(function(a,b){return PeriodLabels.indexOf(a.key)-PeriodLabels.indexOf(b.key);});

    ListPreProcessing(EdgeList); //Solo una vez

    var maxCrimes = d3.max(csData.GroupNodes.all(), function(d) { return d.value; });
    renderPolilynes(maxCrimes);
    refresh_Palette(maxCrimes);
    render_Charts();
}

function renderPolilynes(maxCrimes) {
    var hotlineConfig = { min: 0, max: maxCrimes, palette: colorPalette, weight: 4, outlineColor: '#000', outlineWidth: 0.0 }
    EdgeList.forEach(function(f) {
        let inicio = 0;
        let fin = 0;
        csData.GroupNodes.all().forEach(function(s) { if (s.key == f.a) { inicio = s.value; }; if (s.key == f.b) { fin = s.value; }; });
        latlongs = Pass_Interpolation(f.geometry.coordinates, parseFloat(f.cumulativo), inicio, fin);
        polyline = L.hotline(latlongs, hotlineConfig);
        polyline.bindPopup("</br>" + f.name);
        polylines.push(polyline);
        polyline.addTo(map);
    });
}
function render_Charts() {
    //setwidth div
    var divTypeChart   = document.getElementById("ChartCrimeType");
    var divChartMonth  = document.getElementById("ChartMonthAcumulado");
    var divChartDay    = document.getElementById("ChartDay");
    var divChartPeriod = document.getElementById("ChartPeriod");

    //var divTypeChartHeight = csData.CrimeTypes.all().length * 30;
    var divTypeChartHeight      = barchartclientHeigh * 0.35;
    var divMonthChartHeight     = barchartclientHeigh * 0.60;
    var divDayChartHeight       = barchartclientHeigh * 0.37;
    var divPeriodChartHeight    = barchartclientHeigh * 0.23;


    var TypeChart       = dc.rowChart("#ChartCrimeType");
	var MonthChart      = dc.rowChart("#ChartMonthAcumulado");
	var DayChart        = dc.rowChart("#ChartDay");
	var PeriodChart     = dc.rowChart("#ChartPeriod");
	
    var temporalChart   = dc.lineChart("#temporalChartLine");

    var minDate         = csData.dimTime.bottom(1)[0]["date"];
    var maxDate         = csData.dimTime.top(1)[0]["date"];

    var runMin          = 0;
    var runMax          = d3.max(csData.time.all(), function(f) { return f.value })
	
	/* ------- Crime type barchart -------------*/
    TypeChart.width(barchartclientWidth)
        .height(divTypeChartHeight)
        .dimension(csData.dimCrimeType)
        .group(csData.CrimeTypes)
        .margins({top: 10, right: 40, bottom: 25, left: 10})
        .renderTitle(true)
        .title(function(d) { return d.key + "  " + d.value })
        .colors(["#F48964"]) //,"#ff0000", "#ff4040","#ff7373","#67e667","#39e639","#00cc00"])
        .colorDomain([0, 0])
        .renderlet(function(chart) {})
        .on("filtered", function() {
            deleteGraph();
            var maxCrimes = d3.max(csData.GroupNodes.all(), function(d) { return d.value; });
            refresh_Palette(maxCrimes);
            renderPolilynes(maxCrimes);

        });
	 /* ------- Crime type barchart -------------*/
	 
	 var MonthLabels  = ['Jan', 'Fev', 'Mar', 'Abr',  'Mai',  'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];//["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
     /* ------- Month barchart -------------*/
     MonthChart.width(barchartclientWidth*0.45)
        .height(divMonthChartHeight)
        .dimension(csData.dimlabelMonth)
        .group(snap_to_zero(csData.labelMonth))
        .margins({top: 10, right: 5, bottom: 25, left: 10})
        .renderTitle(true)
        .title(function(d) { return d.key + "  " + d.value })
        .colors(["#EDBF6F"]) //,"#ff0000", "#ff4040","#ff7373","#67e667","#39e639","#00cc00"])
        .colorDomain([0, 0])
        .ordering(function(d) { return MonthLabels.indexOf(d.key); }) //OPTION A
        .renderlet(function(chart) {})
        .on("filtered", function() {
            deleteGraph();
            var maxCrimes = d3.max(csData.GroupNodes.all(), function(d) { return d.value; });
            refresh_Palette(maxCrimes);
            renderPolilynes(maxCrimes);

        })
        .xAxis().ticks(8);
	 /* ------- Month barchart -------------*/
	 
     /* ------- Day barchart -------------*/
     DayChart.width(barchartclientWidth*0.45)
        .height(divDayChartHeight)
        .dimension(csData.dimlabelDay)
        .group(snap_to_zero(csData.labelDay))
        .margins({top: 10, right: 5, bottom: 30, left: 10})
        .renderTitle(true)
        .title(function(d) { return d.key + "  " + d.value })
        .colors(["#F3D84A"]) //,"#ff0000", "#ff4040","#ff7373","#67e667","#39e639","#00cc00"])
        .colorDomain([0, 0])
        .ordering(function(d) { return DayLabels.indexOf(d.key); }) //OPTION A
        .renderlet(function(chart) {})
        .on("filtered", function() {
            deleteGraph();
            var maxCrimes = d3.max(csData.GroupNodes.all(), function(d) { return d.value; });
            refresh_Palette(maxCrimes);
            renderPolilynes(maxCrimes);

        })
        .xAxis().ticks(10);
        
        /* ------- Day barchart -------------*/
     
     
     /* ------- Period barchart -------------*/
     PeriodChart.width(barchartclientWidth*0.45)
        .height(divPeriodChartHeight)
        .dimension(csData.dimlabelPeriod)
        .group(snap_to_zero(csData.labelPeriod))
        .margins({top: 5, right: 5, bottom: 30, left: 10})
        .renderTitle(true)
        .title(function(d) { return d.key + "  " + d.value })
        .colors(["#C64A3D"]) //,"#ff0000", "#ff4040","#ff7373","#67e667","#39e639","#00cc00"])
        .colorDomain([0, 0])
        .ordering(function(d) { return PeriodLabels.indexOf(d.key); }) //OPTION A
        .renderlet(function(chart) {})
        .on("filtered", function() {
            deleteGraph();
            var maxCrimes = d3.max(csData.GroupNodes.all(), function(d) { return d.value; });
            refresh_Palette(maxCrimes);
            renderPolilynes(maxCrimes);

        })
        .xAxis().ticks(8);
     /* ------- Period barchart -------------*/


    temporalChart
        .width(window.innerWidth * 0.95)
        .height(120)
        .transitionDuration(1000)
        .renderHorizontalGridLines(true)

    .x(d3.scaleTime().domain([dateFmt(minDate), dateFmt(maxDate)]))
        .y(d3.scaleLinear().domain([runMin, runMax]))
        //.curve(d3.curveStepBefore)
        .renderArea(true)
        .colors(["#FBBC55"])
        .on("filtered", function() {
            deleteGraph();
            var maxCrimes = d3.max(csData.GroupNodes.all(), function(d) { return d.value; });
            refresh_Palette(maxCrimes);
            renderPolilynes(maxCrimes);
        })
        .brushOn(true) //false se ponen los puntos
        .renderDataPoints(true)
        .clipPadding(10)
        .yAxisLabel("crimes")
        //.xAxisLabel("Date")
        .dimension(csData.dimTime)
        .group(csData.time)
        .renderTitle(true)
        .title(function(d) {
            var value = d.value;
            if (isNaN(value)) {
                value = 0;
            }
            return (d.key.toLocaleDateString()) + '  -  ' + parseInt(value);
        })
        .xAxis().tickFormat(function(v) { return v.toLocaleDateString(); })

    dc.renderAll();
}


function ListPreProcessing(EdgeList) {
    EdgeList.forEach(function(e) {
        var polyline = L.polyline(e.geometry.coordinates);
        cumulativo = 0;
        previousPoint = null;
        polyline.getLatLngs().forEach(function(latLng, i) {
            if (previousPoint) {
                let dis = previousPoint.distanceTo(latLng).toFixed(2);
                cumulativo = cumulativo + parseFloat(dis);
                e.geometry.coordinates[i][2] = cumulativo;
            }
            e.geometry.coordinates[i][2] = cumulativo;
            let aux = e.geometry.coordinates[i][0];
            e.geometry.coordinates[i][0] = e.geometry.coordinates[i][1];
            e.geometry.coordinates[i][1] = aux;
			
            previousPoint = latLng;
        });
        e["cumulativo"] = cumulativo;
    });
}

function Pass_Interpolation(coordinates, maximo, value1, value2) {
    result = [];
    coordinates.forEach(function(d) {
        let inter = (((value2 - value1) * (parseFloat(d[2]))) / maximo) + value1
        result.push([d[0], d[1], inter]);
    });
    return result;
}

function refresh_Palette(maximo) {
    map.removeLayer(legend);

    var numTicks;
    if (maximo >= 50) {
        numTicks = 10;
    } else if (maximo >= 10 && maximo < 50) {
        numTicks = 5;
    } else {
        numTicks = 3;
    };

    var color1 = d3.scaleLinear()
        .domain([0, maximo])
        .range(colorScale)

    var arrayTicks = color1.ticks(numTicks);

    legend.onAdd = function(map) {
        var div = L.DomUtil.create('div', 'info legend'),
            grades = arrayTicks,
            labels = [];
        // loop through our density intervals and generate a label with a colored square for each interval
        for (var i = grades.length - 1; i >= 0; i--) {
            div.innerHTML +=
                '<i style="background:' + color1(grades[i]) + '"></i> ' +
                grades[i] + '<br>';
        }
        return div;
    };
    legend.addTo(map)
}
//main_Crossfilter();
//testeMYFUNCTION();