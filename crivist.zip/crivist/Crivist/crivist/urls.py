# -*- coding: utf-8 -*-
from django.conf.urls import include,url

from .views import HomePageView,get_Graph,ImprovedGraph,Random_ImprovedGraph,Preprocessing_Graph,Preprocessing_Graph_Second,Preprocessing_Graph_Circle,Preprocessing_Graph_Crime_EC_T_V,Preprocessing_Graph_Circle_Crime_EC_T_V

urlpatterns=[
	url(r'^$', HomePageView.as_view(), name = 'home'),
	url(r'^get_Graph/$', get_Graph, name = 'get_Graph'),
	url(r'^ImprovedGraph/$', ImprovedGraph, name = 'ImprovedGraph'),
	url(r'^Random_ImprovedGraph/$', Random_ImprovedGraph, name = 'Random_ImprovedGraph'),
	url(r'^Preprocessing_Graph/$', Preprocessing_Graph, name = 'Preprocessing_Graph'),
	url(r'^Preprocessing_Graph_Second/$', Preprocessing_Graph_Second, name = 'Preprocessing_Graph_Second'),
	url(r'^Preprocessing_Graph_Circle/$', Preprocessing_Graph_Circle, name = 'Preprocessing_Graph_Circle'),

	url(r'^Preprocessing_Graph_Circle_Crime_EC_T_V/$', Preprocessing_Graph_Circle_Crime_EC_T_V, name = 'Preprocessing_Graph_Circle_Crime_EC_T_V'),
	url(r'^Preprocessing_Graph_Crime_EC_T_V/$', Preprocessing_Graph_Crime_EC_T_V, name = 'Preprocessing_Graph_Crime_EC_T_V'),
]