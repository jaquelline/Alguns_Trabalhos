# -*- coding: utf-8 -*-
import csv,sys,os
import django
import time
from datetime import datetime
import random
from django.contrib.gis.geos import GEOSGeometry,Point
import shapefile

from django.contrib.gis.utils import LayerMapping

django.setup()
from .models import Roubo_Crimes,Nodes,Edges,ModeloCompacto,DriveModeloCompacto,Crime_EC_T_V,WalkModeloCompacto

def generateHour(start,end):
	hours = random.randint(start, end)
	minutes = random.randint(0, 59)
	seconds = random.randint(0, 59)
	return str(hours)+':'+str(minutes)+':'+str(seconds)
	#composto = datetime.strptime(str(hours)+':'+str(minutes)+':'+str(seconds),'%H:%M:%S')
	#return composto.time()
def load_Crime_EC_T_V():
	error = []
	data=csv.reader(open("D:\\NEV_DATA_Crivist_JOIN_NEV\\EstCom_Transe_veiculo.csv"),delimiter=",")
	for row in data:
		roubo=Crime_EC_T_V()
		roubo.codsetor  = row[2].split('.')[0]
		roubo.dateCrime = time.strftime(row[4] + ' '+ row[6])
		roubo.tipoCrime = row[3]
		lng = row[8]
		lat = row[7]
		if(',' in lng): lng = lng.replace(',','.')
		if(',' in lat): lat = lat.replace(',','.')
		roubo.coord_x	= lng 
		roubo.coord_y	= lat 
		roubo.point 	= 'SRID=32140;POINT('+lng+" "+lat+")" 
		roubo.codnode	= ''
		roubo.Geom	    = row[5]
		try:
			roubo.save()
		except:
			error.append(row[0])
	print("end-----------")
	print(error)

def run():
	data=csv.reader(open("F:\\DOWNLOAD\\routros6_17_CeMEAI_corregido_Final_coma.csv"),delimiter=",")
	for row in data:
		roubo=Roubo_Crimes()
		roubo.codsetor=str(row[8])
		roubo.num_bo=row[2]
		hora = str(row[4])
		if (row[4] == 'PELA MANHÃ' or row[4] == 'PELA MANHÃƒ' or row[4] =='0'):
			hora = str(generateHour(6,11))
		date = time.strftime(row[3] + ' '+ hora)
		roubo.data=date
		roubo.tipoCrime=row[6]
		roubo.station=row[5]
		roubo.coord_x=row[9]
		roubo.coord_y=row[10]
		roubo.point='SRID=32140;POINT('+row[9]+" "+row[10]+")"
		roubo.save()
	print("end-----------")

def LOADDATA_CleanRoubos20016_2017():
	path ="D:\\NEV_DATA\\Base_Roubo_2006_2017\\"
	data=csv.reader(open(path+"routros6_17_CeMEAIWithNodes_Number.csv"),delimiter=",")
	print("COMENZO")
	for row in data:
		mycrime                 = Second_Roubo()
		mycrime.codsetor 		= row[7]
		hora = str(row[3])
		if (row[3] == 'PELA MANHÃ' or row[3] == 'PELA MANHÃƒ' or row[3] =='0'):
			hora = str(generateHour(6,11))
		date = time.strftime(row[2] + ' '+ hora)
		
		mycrime.data			= date

		temp 					= str(row[5]) 									#get crime type
		temp 					= ' '.join(temp.split())
		
		mycrime.tipoCrime		= temp

		temp2 	= str(row[4])
		temp2 	= ' '.join(temp2.split())
		
		mycrime.station			= temp2
		mycrime.coord_x			= row[8]
		mycrime.coord_y			= row[9]
		mycrime.point 			= 'SRID=32140;POINT('+row[8]+" "+row[9]+")"
		mycrime.codnode			= row[10]
		mycrime.save()
	print("TERMINE")

def  run_W():
	data=csv.reader(open("F:\\UspDrive\\2_Stage\\routros6_17_CeMEAI_corregido_Final_WithPreProcessing.csv"),delimiter=",")
	for row in data:
		roubo=Roubo_Crimes()
		roubo.codsetor=str(row[8])
		roubo.num_bo=row[2]
		hora = str(row[4])
		if (row[4] == 'PELA MANHÃ' or row[4] == 'PELA MANHÃƒ' or row[4] =='0'):
			hora = str(generateHour(6,11))
		date = time.strftime(row[3] + ' '+ hora)
		roubo.data=date

		temp 	= str(row[6]) 									#get crime type
		temp 	= ' '.join(temp.split())							#crime type name cleaning

		roubo.tipoCrime=temp

		temp2 	= str(row[5])
		temp2 	= ' '.join(temp2.split())

		roubo.station=temp2
		roubo.coord_x=row[9]
		roubo.coord_y=row[10]
		roubo.point='SRID=32140;POINT('+row[9]+" "+row[10]+")"
		roubo.codnode=row[11] #code
		roubo.save()
	print("end-----------")

from geojson import Point, Feature, FeatureCollection, dump
def testRun():
	data=csv.reader(open("C:\\Users\\garci\\Google Drive\\2_Stage\\routros6_17_CeMEAI_corregido_Final_WithPreProcessing.csv"),delimiter=",")
	features=[]
	for row in data:
		dic={}
		dic["codsetor"]=str(row[8])
		dic["num_bo"]=row[2]
		temp 	= str(row[6]) 									#get crime type
		temp 	= ' '.join(temp.split())							#crime type name cleaning

		dic["tipoCrime"]=temp

		dic["coord_x"]=row[9]
		dic["coord_y"]=row[10]

		point = Point((float(row[9]), float(row[10])))
		features.append(Feature(geometry=point, properties=dic))
	feature_collection = FeatureCollection(features)

	with open('D:\\leaftlet\\d3Points\\myfile.geojson', 'w') as f:
		dump(feature_collection, f)

def loadNodes():
	data=csv.reader(open("D:\\walk_SaoPauloEstricto\\ListofNodes.csv"),delimiter=",")
	#data=csv.reader(open("D:\\SaoPauloGraph\\New\\ListofNodes.csv"),delimiter=",")
	for row in data:
		node=Nodes()
		node.osmid=row[0]
		node.coord_x=row[1]
		node.coord_y=row[2]	
		node.point='SRID=32140;POINT('+row[1]+" "+row[2]+")"
		node.dist=""#row[3]
		node.save()
	print("Termine NODES")

def loadEdges():
	#read a json
	reader = shapefile.Reader("D:\\SaoPauloGraph\\edges\\edges.shp")
	fields = reader.fields[1:]
	field_names = [field[0] for field in fields]
	buffer = []
	nodes={}
	for sr in reader.shapeRecords():
		atr = dict(zip(field_names, sr.record))
		geom = sr.shape.__geo_interface__
		buffer.append(dict(type="Feature", \
		geometry=geom, properties=atr)) 
	print("COMENZANDO")
	for path in buffer:
		if((str(path['properties']['from'])+"_"+str(path['properties']['to']) in nodes) or (str(path['properties']['to'])+"_"+str(path['properties']['from']) in nodes)):
			pass
		else:
			edges = Edges()
			nodes[str(path['properties']['from'])+"_"+str(path['properties']['to'])]=str(path['properties']['to'])+"_"+str(path['properties']['from'])
			edges.name		= path['properties']['name']
			points=[]
			for i in path['geometry']['coordinates']:
				points.append(str(i[0])+" "+str(i[1]))
			seperator = ','
			geom ={}#EOSGeometry(path['geometry'])
			geom['type']='Polygon'
			geom['coordinates'] = [path['geometry']['coordinates']]
			string=seperator.join(points)
			edges.geom		= GEOSGeometry("POLYGON(("+string+"))") #"POLYGON(("+string+"))"#path['geometry']['coordinates']
			edges.nfrom		= path['properties']['from']
			edges.nto		= path['properties']['to']
			edges.osmid		= path['properties']['osmid']
			edges.highway	= path['properties']['highway']
			edges.save()
	print("TEMRINE")

'''
0 index,
1 ANO_OCORR,
2 NUM_BO,
3 DATA_OCORRENCIA_BO,
4 HORA_OCORRENCIA_BO,
5 NOME_DELEGACIA_CIRC,
6 RUBRICA,
7 FLAG_STATUS,
8 COD_SETOR,
9 COORD_X,
10 COORD_Y'''
#2006-01-13

edges_Mapping = {
    'nfrom': 'from',
    'highway': 'highway',
    'name': 'name',
    'osmid': 'osmid',
    'nto': 'to',
    'geom': 'MULTILINESTRING',
}



def runEDGESUPLOAD(verbose=True):
	path="D:\\walk_SaoPauloEstricto\\edges\\edges.shp"
	lm=LayerMapping(Edges,path,edges_Mapping,transform=False,encoding='iso-8859-1')
	lm.save(strict=True,verbose=verbose)
	print("termine.........")

def loadNodesCompleto():
	#sacar el diccionario de los nodos
	data=csv.reader(open("D:\\SaoPauloGraph\\New\\ListofNodes.csv"),delimiter=",")
	diccionatio={}
	for row in data:
		diccionatio[row[0]]='SRID=32140;POINT('+row[1]+" "+row[2]+")"
	#sacar los Edges
	
	reader = shapefile.Reader("D:\\SaoPauloGraph\\New\\edges\\edges.shp")
	fields = reader.fields[1:]
	field_names = [field[0] for field in fields]
	buffer = []
	nodes={}
	for sr in reader.shapeRecords():
		atr = dict(zip(field_names, sr.record))
		geom = sr.shape.__geo_interface__
		buffer.append(dict(type="Feature", \
		geometry=geom, properties=atr)) 
	print("COMENZANDO")
	for path in buffer:
		if((str(path['properties']['from'])+"_"+str(path['properties']['to']) in nodes) or (str(path['properties']['to'])+"_"+str(path['properties']['from']) in nodes)):
			pass
		else:
			mymodelo = ModeloCompacto()
			nodes[str(path['properties']['from'])+"_"+str(path['properties']['to'])]=str(path['properties']['to'])+"_"+str(path['properties']['from'])
			mymodelo.name				= path['properties']['name']
			mymodelo.osmid				= path['properties']['osmid']
			mymodelo.nfrom				= path['properties']['from']
			mymodelo.nto				= path['properties']['to']		
			mymodelo.geom 				= path['geometry']		
			mymodelo.highway			= path['properties']['highway']
			mymodelo.pointFrom			= diccionatio[path['properties']['from']]
			mymodelo.pointTo			= diccionatio[path['properties']['to']]
			mymodelo.save()
	print("TERMINE...................")


def loadNodesCompletoX():
	#sacar el diccionario de los nodos
	data=csv.reader(open("D:\\SaoPauloGraph\\New\\ListofNodes.csv"),delimiter=",")
	diccionatio={}
	for row in data:
		diccionatio[row[0]]='SRID=32140;POINT('+row[1]+" "+row[2]+")"
	#sacar los Edges
	ListEdges = list(Edges.objects.filter())

	for edge in ListEdges:
		mymodelo = ModeloCompacto()
		mymodelo.name				= edge.name
		mymodelo.osmid				= edge.osmid
		mymodelo.nfrom				= edge.nfrom
		mymodelo.nto				= edge.nto
		mymodelo.geom				= edge.geom
		mymodelo.highway			= edge.highway
		mymodelo.pointFrom			= diccionatio[edge.nfrom]
		mymodelo.pointTo			= diccionatio[edge.nto]
		mymodelo.save()
	print("TERMINE...................")

import json 
def WalkloadNodesCompleto():
	#sacar el diccionario de los nodos
	data=csv.reader(open("D:\\walk_SaoPauloEstricto\\ListofNodes.csv"),delimiter=",")
	diccionatio={}
	for row in data:
		diccionatio[row[0]]='SRID=32140;POINT('+row[1]+" "+row[2]+")"
	#sacar los Edges
	
	reader = shapefile.Reader("D:\\walk_SaoPauloEstricto\\edges\\edges.shp")
	#reader = shapefile.Reader("D:\\WorkShop\\New Folder\\edge.shp")
	fields = reader.fields[1:]
	field_names = [field[0] for field in fields]
	buffer = []
	nodes={}
	for sr in reader.shapeRecords():
		atr = dict(zip(field_names, sr.record))
		geom = sr.shape.__geo_interface__
		buffer.append(dict(type="Feature", \
		geometry=geom, properties=atr)) 
	print("COMENZANDO")
	for path in buffer:
		if((str(path['properties']['from'])+"_"+str(path['properties']['to']) in nodes) or (str(path['properties']['to'])+"_"+str(path['properties']['from']) in nodes)):
			pass
		else:
			mymodelo = WalkModeloCompacto()
			nodes[str(path['properties']['from'])+"_"+str(path['properties']['to'])]=str(path['properties']['to'])+"_"+str(path['properties']['from'])
			mymodelo.name				= path['properties']['name']
			mymodelo.osmid				= path['properties']['osmid']
			mymodelo.nfrom				= path['properties']['from']
			mymodelo.nto				= path['properties']['to']	
			print(type(path['geometry']),json.dumps(path['geometry']))

			mymodelo.geom 				= GEOSGeometry(json.dumps(path['geometry']	))	
			mymodelo.highway			= path['properties']['highway']
			mymodelo.pointFrom			= diccionatio[path['properties']['from']]
			mymodelo.pointTo			= diccionatio[path['properties']['to']]
			mymodelo.save()
	print("TERMINE...................walk")	

def DriveloadNodesCompletoX():
	#sacar el diccionario de los nodos
	data=csv.reader(open("D:\\walk_SaoPauloEstricto\\ListofNodes.csv"),delimiter=",")
	diccionatio={}
	for row in data:
		diccionatio[row[0]]='SRID=32140;POINT('+row[1]+" "+row[2]+")"
	#sacar los Edges
	ListEdges = list(Edges.objects.filter())
	print("INICIANDO")
	for edge in ListEdges:
		mymodelo = WalkModeloCompacto()
		mymodelo.name				= edge.name
		mymodelo.osmid				= edge.osmid
		mymodelo.nfrom				= edge.nfrom
		mymodelo.nto				= edge.nto
		mymodelo.geom				= edge.geom
		mymodelo.highway			= edge.highway
		mymodelo.pointFrom			= diccionatio[edge.nfrom]
		mymodelo.pointTo			= diccionatio[edge.nto]
		mymodelo.save()
	print("TERMINE...................walks")



