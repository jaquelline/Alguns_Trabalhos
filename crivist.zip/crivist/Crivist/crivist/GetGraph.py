import csv,sys,os
from django.contrib.gis.geos import GEOSGeometry,Point
from functools import partial
#from django.contrib.gis.geos import GEOSGeometry,Point
from shapely.geometry import Point,Polygon
from django.contrib.gis.geos import GEOSGeometry
from shapely.ops import transform
import pyproj
import numpy as np
from .models import Nodes,Edges
from .utils import GetPolygonWithArrays


def GetEdges():
    path="D:\\SaoPauloGraph\\New\\"
    MyEdges= list(Edges.objects.filter().only('osmid','nfrom','nto'))
    respuesta=[]
    for ed in MyEdges:
        print("Iniciando")
        respuesta.append([ed.osmid,ed.nfrom,ed.nto])
    np.savetxt(path+"edges.csv", np.array(respuesta), fmt="%s", delimiter=',')
    print("Terminei")


    