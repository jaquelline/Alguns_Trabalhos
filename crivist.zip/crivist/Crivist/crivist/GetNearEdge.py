import csv,sys,os
import django
import time
from datetime import datetime
import random
from django.contrib.gis.geos import GEOSGeometry,Point
import shapefile
from .models import Nodes,Edges,Second_Roubo,Crime_EC_T_V
import geopandas as gpd
from .utils import GetPolygonWithArrays
####################################33
from shapely.geometry import Point
import csv
from shapely.geometry.polygon import Polygon

import networkx as nx
import osmnx as ox

######################################

place_names = ['Anhanguera,São Paulo, BR','São Paulo, BR','Caieiras,São Paulo, BR',
               'Cajamar,São Paulo, BR','Francisco Morato,São Paulo, BR',
               'Franco da Rocha,São Paulo, BR','Mairiporã,São Paulo, BR',
               'Arujá,São Paulo, BR','Biritiba-Mirim,São Paulo, BR',
               'Ferraz de Vasconcelos,São Paulo, BR','Guararema,São Paulo, BR',
               'Itaquaquecetuba,São Paulo, BR','Guarulhos,São Paulo, BR',
               'Mogi das Cruzes,São Paulo, BR','Poá,São Paulo, BR',
               'Salesópolis,São Paulo, BR','Santa Isabel,São Paulo,BR',
               'Suzano,São Paulo, BR','Diadema,São Paulo, BR',
               'Mauá,São Paulo, BR','Santo André,São Paulo, BR',
               'São Bernardo do Campo,São Paulo, BR',
               'São Caetano do Sul,São Paulo, BR',
               'Ribeirão Pires,São Paulo, BR','Rio Grande da Serra,São Paulo, BR',
               'Cotia,São Paulo, BR','Embu,São Paulo, BR','Embu-Guaçu,São Paulo, BR',
               'Itapecerica da Serra,São Paulo, BR','Juquitiba,São Paulo, BR',
               'São Lourenço da Serra,São Paulo, BR','Taboão da Serra,São Paulo, BR',
               'Vargem Grande Paulista,São Paulo, BR','Barueri,São Paulo, BR',
               'Carapicuíba,São Paulo, BR','Itapevi,São Paulo, BR',
               'Jandira,São Paulo, BR','Osasco,São Paulo, BR',
               'Pirapora do Bom Jesus,São Paulo, BR',
               'Santana de Parnaíba,São Paulo, BR']

def shapeFromPlace():
    #saopaulocities = ox.gdf_from_places(place_names, gdf_name='')
    print("INICIANDO")

    for name in place_names:
        print(name)
        G=ox.core.graph_from_place(name,network_type='drive',simplify=False, retain_all=False, truncate_by_edge=True)
        G2 = G.copy()
        G2 = ox.simplify_graph(G2, strict=False)

        shape   = ox.gdf_from_place(name, gdf_name='')
        polygon = shape.loc[0,'geometry']
        
        Lista   =  Crime_EC_T_V.objects.filter(point__within=polygon)
        for ele in Lista:
            lat = ele.coord_y
            lng = ele.coord_x
            geom, u, v = ox.get_nearest_edge(G, (lat, lng))
            nn = min((u, v), key=lambda n: ox.great_circle_vec(lat, lng, G.node[n]['y'], G.node[n]['x']))
            ele.codnode = nn
            ele.save()
    print("TERMINE")



def Second_shapeFromPlace():
        shapefile = gpd.read_file("D:\\NEV_DATA_Crivist_JOIN_NEV\\Test_NearestEdge\\data\\sp\\sp.shp")
        dictionaty={}
        for index, row in shapefile.iterrows():
                x, y = row['geometry'].exterior.coords.xy
                pos = GetPolygonWithArrays(x,y)
                dictionaty[row['dist']] =  GEOSGeometry(pos)
	
        for name, poly in dictionaty.items():
                print(name)
                G=ox.core.graph_from_place(name,network_type='drive',simplify=False, retain_all=False, truncate_by_edge=True)
                G2 = G.copy()
                G2 = ox.simplify_graph(G2, strict=False)
                Lista   =  Crime_EC_T_V.objects.filter(point__within=poly)
                for ele in Lista:
                        lat = ele.coord_y
                        lng = ele.coord_x
                        geom, u, v = ox.get_nearest_edge(G, (lat, lng))
                        nn = min((u, v), key=lambda n: ox.great_circle_vec(lat, lng, G.node[n]['y'], G.node[n]['x']))
                        ele.codnode = nn
                        ele.save()
        print("TERMINE")