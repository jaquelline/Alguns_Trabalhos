# -*- coding: utf-8 -*-
from django.shortcuts import render
from django.views.generic import TemplateView
from django.core.serializers import serialize
from django.http import HttpResponse
from datetime import datetime, date, time, timedelta
from django.contrib.gis.db.models import PointField
from shapely import geometry
from django.contrib.gis.geos import GEOSGeometry,Point,Polygon,MultiLineString
import json
import osmnx as ox
import networkx as nx
from networkx.readwrite import json_graph
from .models import Roubo_Crimes,ModeloCompacto,Second_Roubo,Crime_EC_T_V
import json
import random
import shapely
from shapely.geometry import Point as pt
from shapely.geometry import mapping, shape
from .utils import GetPolygonWithArrays
from .utils import GetLabelofDate
from .CleanData import geodesic_point_buffer
from django.http import JsonResponse
import numpy as np
from shapely.ops import transform
from django.db.models import Count

#import geojson

SP_ne = (-46.336531, -23.396967)
SP_sw = (-47.025619, -23.852432) 
xmin = SP_sw[0]
ymin = SP_ne[1]
xmax = SP_sw[0]
ymax = SP_ne[1]
bbox = (xmin, ymin, xmax, ymax)
#SaoPaulo_Box = Polygon.from_bbox(bbox)
SaoPaulo_Box = shapely.geometry.Polygon([(-47.432923,-23.419904),(-46.120644 , -23.268599),(-45.950432 , -23.737080),(-47.279184  ,-23.892869),(-47.432923 , -23.419904)])

formato_fecha = "%Y-%m-%d %H:%M:%S+00:00"
# Create your views here.
class HomePageView(TemplateView):
	template_name = 'index.html'


def to_json(graph):
    """Converts this graph to a Node-Link JSON object

    :param BELGraph graph: A BEL graph
    :return: A Node-Link JSON object representing the given graph
    :rtype: dict
    """
    graph_json_dict = json_graph.node_link_data(graph)
    graph_json_dict['graph'][GRAPH_ANNOTATION_LIST] = {
        k: list(sorted(v))
        for k, v in graph_json_dict['graph'][GRAPH_ANNOTATION_LIST].items()
    }
    graph_json_dict['graph'][GRAPH_UNCACHED_NAMESPACES] = list(graph_json_dict['graph'][GRAPH_UNCACHED_NAMESPACES])

    return graph_json_dict


def Preprocessing_Graph_Second(request):
	lngs                = json.loads(request.GET.get('lats'))
	lats                = json.loads(request.GET.get('lngs'))
	pos                 = GetPolygonWithArrays(lats,lngs)
	polygon             = GEOSGeometry(pos)
	ListCrimes        	= list(Second_Roubo.objects.filter(point__within=polygon).only('codsetor','data','tipoCrime','coord_x','coord_y','codnode'))

	resultado=[]
	for crime in ListCrimes:
		date 	= datetime.strptime(str(crime.data),formato_fecha)	#get crime date
		[nameMonth,nameDay,periodDay]=GetLabelofDate(date)
		resultado.append({'codnode':crime.codnode,'date':date.strftime("%d-%m-%Y %H:%M:%S"), 'crimeType':crime.tipoCrime,'codsetor':crime.codsetor,'labelMonth':nameMonth,'labelDay':nameDay,'labelPeriod':periodDay})
		#resultado.append({'codnode':crime.codnode, 'crimeType':crime.tipoCrime,'codsetor':crime.codsetor})
	
	edgesList = list(ModeloCompacto.objects.filter(pointFrom__within=polygon))
	'''print("-------------------------------------")
	print(getPolygonCoordinates(edgesList[0].geom.convex_hull))

	print("-------------------------------------")'''
	res=[]
	for ed in edgesList:
		res.append({"name":ed.name,'nfrom':ed.nfrom,'nto':ed.nto,'geom':getPolygonCoordinates(ed.geom.convex_hull)})

	return HttpResponse(json.dumps({"Crimes":resultado,"EdgeList":res}),content_type='application/json')


def Preprocessing_Graph_Circle(request):
	lat                = float(json.loads(request.GET.get('lat')))
	lng                = float(json.loads(request.GET.get('lng')))
	radio               = int(json.loads(request.GET.get('radius')))

	buffer =np.array(geodesic_point_buffer(float(lat),float(lng),radio))
	latitudes = buffer.T[1].tolist()
	longitudes = buffer.T[0].tolist()
	pos = GetPolygonWithArrays(longitudes,latitudes)
	polygon             = GEOSGeometry(pos)
	po=pt(float(lng),float(lat))

	if(SaoPaulo_Box.contains(po)):
		return mainExecutionPolygon(polygon,longitudes,latitudes)
	else:
		return HttpResponse(json.dumps({"error":str("Endereço Fora do São Paulo")}),content_type='application/json')


def Preprocessing_Graph(request):
	lngs                = json.loads(request.GET.get('lats'))
	lats                = json.loads(request.GET.get('lngs'))
	pos                 = GetPolygonWithArrays(lats,lngs)
	polygon             = GEOSGeometry(pos)

	return mainExecutionPolygon(polygon,lats,lngs)

def mainExecutionPolygon(polygon,lats,lngs):
	#print(Roubo_Crimes.objects.values('tipoCrime').annotate(count()))
	#print(Roubo_Crimes.objects.all().annotate(Count('tipoCrime', 
    #                                     distinct=True)))
	Aux        	= Roubo_Crimes.objects.filter(point__within=polygon).only('codsetor','data','tipoCrime','coord_x','coord_y','codnode')
	ListCrimes  = list(Aux)
	indicador = 5
	Counting=Aux.values('tipoCrime').annotate(count=Count('tipoCrime')).order_by('count').reverse()
	elegidos = []
	for arr in Counting:
		elegidos.append(arr['tipoCrime'])

	if (len(elegidos)>indicador):
		elegidos=elegidos[0:indicador]
	
	pointList=[]
	for i in range(len(lats)):
		pointList.append( geometry.Point(lats[i],lngs[i]))
	pointList.append( geometry.Point(lats[0],lngs[0]))
	poly = geometry.Polygon([[p.x, p.y] for p in pointList])

	try:
		G = ox.core.graph_from_polygon(poly, network_type='drive', simplify=True, retain_all=False, truncate_by_edge=True)
		#G = ox.save_load.get_undirected(G)

		NodeDic={}
		for tp in list(G.nodes(data=True)):
			NodeDic[str(tp[0])]={'osmid':str(tp[1]['osmid']),'x':str(tp[1]['x']),'y':str(tp[1]['y']),'crime':0}

		resultado=[]
		for crime in ListCrimes:
			if(crime.tipoCrime in elegidos):
				try:
					NodeDic[str(crime.codnode)]['crime']+=1
				except:
					pass
				date 	= datetime.strptime(str(crime.data),formato_fecha)	#get crime date
				[nameMonth,nameDay,periodDay]=GetLabelofDate(date)
				resultado.append({'codnode':crime.codnode,'date':date.strftime("%d-%m-%Y %H:%M:%S"), 'crimeType':crime.tipoCrime,'codsetor':crime.codsetor,'labelMonth':nameMonth,'labelDay':nameDay,'labelPeriod':periodDay,'coord_x':crime.coord_x,'coord_y':crime.coord_y})
				#resultado.append({'codnode':crime.codnode, 'crimeType':crime.tipoCrime,'codsetor':crime.codsetor})

		EdgeList=[]
		for ed in list(G.edges(data=True)):
			if(NodeDic[str(ed[0])]['crime'] >=0 or NodeDic[str(ed[1])]['crime']>=0):
				if('geometry' in ed[2].keys()):
					midic={}
					midic['a']=ed[0]
					midic['b']=ed[1]
					#midic['geometry']=mapping((ed[2]['geometry']))
					inicio=Point(float(NodeDic[str(ed[0])]['x']),float(NodeDic[str(ed[0])]['y']))
					fin=Point(float(NodeDic[str(ed[1])]['x']),float(NodeDic[str(ed[1])]['y']))
					midic['geometry']=createGeometry(mapping((ed[2]['geometry'])),inicio,fin,NodeDic[str(ed[0])]['crime'],NodeDic[str(ed[1])]['crime'])
					midic['name']=''
					if ('name' in ed[2].keys()):
						midic['name']=ed[2]['name']
					EdgeList.append(midic)
		return HttpResponse(json.dumps({"Crimes":resultado,"EdgeList":EdgeList}),content_type='application/json')
	except Exception as e:
		return HttpResponse(json.dumps({"error":str(e)}),content_type='application/json')


def GetGraph(lats,lngs):
	pos                 = GetPolygonWithArrays(lats,lngs)
	polygon             = GEOSGeometry(pos)
	ListCrimes          = list(Roubo_Crimes.objects.filter(point__within=polygon).only('codsetor','data','tipoCrime','coord_x','coord_y','point'))


	pointList=[]
	for i in range(len(lats)):
		pointList.append( geometry.Point(lats[i],lngs[i]))
	pointList.append( geometry.Point(lats[0],lngs[0]))
	poly = geometry.Polygon([[p.x, p.y] for p in pointList])

	
	G = ox.core.graph_from_polygon(poly, network_type='drive', simplify=True, retain_all=False, truncate_by_edge=True)
	G = ox.save_load.get_undirected(G)
	maximo = 0
	#List of Nodes
	NodeDic={}
	for tp in list(G.nodes(data=True)):
		NodeDic[tp[0]]={'osmid':str(tp[1]['osmid']),'x':str(tp[1]['x']),'y':str(tp[1]['y']),'crime':0,'point':'SRID=32140;POINT('+str(tp[1]['x'])+" "+str(tp[1]['y'])+")"}
		#NodeDic[tp[0]]={'osmid':str(tp[1]['osmid']),'x':str(tp[1]['x']),'y':str(tp[1]['y']),'crime':random.randint(0, 15),'point':'SRID=32140;POINT('+str(tp[1]['x'])+" "+str(tp[1]['y'])+")"}
	for crime in ListCrimes:
		key=clossest_Point(crime.point,NodeDic)
		NodeDic[key]['crime']+=1
		if(NodeDic[key]['crime']>maximo):
			maximo=maximo+1

	#List of edges
	'''EdgeList=[]
	for ed in list(G.edges(data=True)):
	    if('geometry' in ed[2].keys()):
	        midic={}
	        midic['a']=ed[0]
	        midic['b']=ed[1]
	        midic['geometry']=geometry.mapping((ed[2]['geometry']))
	        midic['name']=''
	        if ('name' in ed[2].keys()):
	            midic['name']=ed[2]['name']
	        EdgeList.append(midic)'''
	EdgeList=[]
	for ed in list(G.edges(data=True)):
	    if('geometry' in ed[2].keys()):
	        midic={}
	        midic['a']=ed[0]
	        midic['b']=ed[1]
	        #midic['geometry']=mapping((ed[2]['geometry']))
	        inicio=Point(float(NodeDic[ed[0]]['x']),float(NodeDic[ed[0]]['y']))
	        fin=Point(float(NodeDic[ed[1]]['x']),float(NodeDic[ed[1]]['y']))
	        midic['geometry']=createGeometry(mapping((ed[2]['geometry'])),inicio,fin,NodeDic[ed[0]]['crime'],NodeDic[ed[1]]['crime'])
	        midic['name']=''
	        if ('name' in ed[2].keys()):
	            midic['name']=ed[2]['name']
	        EdgeList.append(midic)
	return [EdgeList,maximo]

def clossest_Point(point,dic):
	minimo=1000
	resp=""
	for key,value in dic.items():
		dis=GEOSGeometry(value['point']).distance(GEOSGeometry(point))
		if(dis<minimo): #AQUI ESTA EL ERROR
			resp=key
			minimo=dis
	return resp

def interpolacion(inicio,fin,value1,value2,Intermedio):
	if(inicio.distance(fin)==0):
		return value1
	else:
		result=(((value2-value1)*(inicio.distance(Intermedio)))/inicio.distance(fin))+value1
		return result
    
def createGeometry(temp,pointInicio ,pointFin,inicialValue,endValue):
    puntos=[]
    for ase in temp['coordinates']:
        result=interpolacion(pointInicio,pointFin,inicialValue,endValue,Point(ase))
        puntos.append([ase[0],ase[1],1
		])#result])
    return { "type": "LineString", "coordinates": puntos }

def Random_ImprovedGraph(request):
	lngs                = json.loads(request.GET.get('lats'))
	lats                = json.loads(request.GET.get('lngs'))
	pos                 = GetPolygonWithArrays(lats,lngs)
	polygon             = GEOSGeometry(pos)
	ListCrimes        	= list(Roubo_Crimes.objects.filter(point__within=polygon).only('codsetor','data','tipoCrime','coord_x','coord_y','point'))

	[EdgeList,maximo]	= GetGraph(lats,lngs)
	
	#We have Crime for Each Node
	return HttpResponse(json.dumps({"EdgeList":EdgeList,"maximo":maximo}),content_type='application/json') 


def ImprovedGraph(request):
	lngs                = json.loads(request.GET.get('lats'))
	lats                = json.loads(request.GET.get('lngs'))
	pos                 = GetPolygonWithArrays(lats,lngs)
	polygon             = GEOSGeometry(pos)
	ListCrimes        = list(Roubo_Crimes.objects.filter(point__within=polygon).only('codsetor','data','tipoCrime','coord_x','coord_y','point'))

	NodeDic 	= GetGraph(lats,lngs)
	for crime in ListCrimes:
		#print('--------------- '+crime.codsetor)
		key=clossest_Point(crime.point,NodeDic)
		if('all' in NodeDic[key]):
			 NodeDic[key]['all']+=1
		else:
			NodeDic[key]['all']=1

		if(str(crime.tipoCrime) in NodeDic[key]):
			NodeDic[key][crime.tipoCrime]+=1
		else:
			NodeDic[key][crime.tipoCrime]=1
	return HttpResponse(json.dumps(NodeDic),content_type='application/json') 


def get_Graph(request):
	lngs                = json.loads(request.GET.get('lats'))
	lats                = json.loads(request.GET.get('lngs'))
	pos                 = GetPolygonWithArrays(lats,lngs)
	polygon             = GEOSGeometry(pos)

	'''
	pointList=[]
	for i in range(len(lats)):
		pointList.append( geometry.Point(lats[i],lngs[i]))
	pointList.append( geometry.Point(lats[0],lngs[0]))
	poly = geometry.Polygon([[p.x, p.y] for p in pointList])

	sele=[]
	Listasetores        = list(Roubo_Crimes.objects.filter(point__within=polygon).only('codsetor','data','tipoCrime','coord_x','coord_y','point'))
	'''

	pointList=[]
	for i in range(len(lats)):
		pointList.append( geometry.Point(lats[i],lngs[i]))
	pointList.append( geometry.Point(lats[0],lngs[0]))
	poly = geometry.Polygon([[p.x, p.y] for p in pointList])

	G = ox.core.graph_from_polygon(poly, network_type='drive', simplify=True, retain_all=False, truncate_by_edge=True)
	G = ox.save_load.get_undirected(G)

	#List of Nodes
	NodeDic={}
	for tp in list(G.nodes(data=True)):
		NodeDic[tp[0]]={'osmid':str(tp[1]['osmid']),'x':str(tp[1]['x']),'y':str(tp[1]['y']),'crime':0}

	#List of edges
	EdgeList=[]
	for ed in list(G.edges(data=True)):
	    if('geometry' in ed[2].keys()):
	        midic={}
	        midic['a']=ed[0]
	        midic['b']=ed[1]
	        midic['geometry']=geometry.mapping((ed[2]['geometry']))
	        midic['name']=''
	        if ('name' in ed[2].keys()):
	            midic['name']=ed[2]['name']
	        EdgeList.append(midic)
	
	return HttpResponse(json.dumps(EdgeList),content_type='application/json')


##########################################################################################
############################  Crime_EC_T_V
##########################################################################################
def Preprocessing_Graph_Circle_Crime_EC_T_V(request):
	lat                = float(json.loads(request.GET.get('lat')))
	lng                = float(json.loads(request.GET.get('lng')))
	radio               = int(json.loads(request.GET.get('radius')))

	buffer =np.array(geodesic_point_buffer(float(lat),float(lng),radio))
	latitudes = buffer.T[1].tolist()
	longitudes = buffer.T[0].tolist()
	pos = GetPolygonWithArrays(longitudes,latitudes)
	polygon             = GEOSGeometry(pos)
	po=pt(float(lng),float(lat))

	if(SaoPaulo_Box.contains(po)):
		return mainExecutionPolygon_Crime_EC_T_V(polygon,longitudes,latitudes)
	else:
		return HttpResponse(json.dumps({"error":str("Endereço Fora do São Paulo")}),content_type='application/json')


def Preprocessing_Graph_Crime_EC_T_V(request):
	lngs                = json.loads(request.GET.get('lats'))
	lats                = json.loads(request.GET.get('lngs'))
	pos                 = GetPolygonWithArrays(lats,lngs)
	polygon             = GEOSGeometry(pos)

	return mainExecutionPolygon_Crime_EC_T_V(polygon,lats,lngs)

def mainExecutionPolygon_Crime_EC_T_V(polygon,lats,lngs):
	Aux        	= Crime_EC_T_V.objects.filter(point__within=polygon).only('dateCrime','tipoCrime','coord_x','coord_y','codnode')
	ListCrimes  = list(Aux)
	indicador = 5
	Counting=Aux.values('tipoCrime').annotate(count=Count('tipoCrime')).order_by('count').reverse()
	elegidos = []
	for arr in Counting:
		elegidos.append(arr['tipoCrime'])

	if (len(elegidos)>indicador):
		elegidos=elegidos[0:indicador]
	
	pointList=[]
	for i in range(len(lats)):
		pointList.append( geometry.Point(lats[i],lngs[i]))
	pointList.append( geometry.Point(lats[0],lngs[0]))
	poly = geometry.Polygon([[p.x, p.y] for p in pointList])

	try:
		#G = ox.core.graph_from_polygon(poly, network_type='drive', simplify=True, retain_all=False, truncate_by_edge=True)
		#G = ox.save_load.get_undirected(G)
		G2  = ox.core.graph_from_polygon(poly,network_type='drive',simplify=False, retain_all=False, truncate_by_edge=True)
		G = G2.copy()
		G = ox.simplify_graph(G, strict=False)

		NodeDic={}
		for tp in list(G.nodes(data=True)):
			NodeDic[str(tp[0])]={'osmid':str(tp[1]['osmid']),'x':str(tp[1]['x']),'y':str(tp[1]['y']),'crime':0}

		resultado=[]
		for crime in ListCrimes:
			if(crime.tipoCrime in elegidos):
				try:
					NodeDic[str(crime.codnode)]['crime']+=1
				except:
					pass
				date 	= datetime.strptime(str(crime.dateCrime),formato_fecha)	#get crime date
				[nameMonth,nameDay,periodDay]=GetLabelofDate(date)
				resultado.append({'codnode':crime.codnode,'date':date.strftime("%d-%m-%Y %H:%M:%S"), 'crimeType':crime.tipoCrime,'codsetor':crime.codsetor,'labelMonth':nameMonth,'labelDay':nameDay,'labelPeriod':periodDay,'coord_x':crime.coord_x,'coord_y':crime.coord_y})
				#resultado.append({'codnode':crime.codnode, 'crimeType':crime.tipoCrime,'codsetor':crime.codsetor})

		EdgeList=[]
		for ed in list(G.edges(data=True)):
			if(NodeDic[str(ed[0])]['crime'] >=0 or NodeDic[str(ed[1])]['crime']>=0):
				if('geometry' in ed[2].keys()):
					midic={}
					midic['a']=ed[0]
					midic['b']=ed[1]
					#midic['geometry']=mapping((ed[2]['geometry']))
					inicio=Point(float(NodeDic[str(ed[0])]['x']),float(NodeDic[str(ed[0])]['y']))
					fin=Point(float(NodeDic[str(ed[1])]['x']),float(NodeDic[str(ed[1])]['y']))
					midic['geometry']=createGeometry(mapping((ed[2]['geometry'])),inicio,fin,NodeDic[str(ed[0])]['crime'],NodeDic[str(ed[1])]['crime'])
					midic['name']=''
					if ('name' in ed[2].keys()):
						midic['name']=ed[2]['name']
					EdgeList.append(midic)
		return HttpResponse(json.dumps({"Crimes":resultado,"EdgeList":EdgeList}),content_type='application/json')
	except Exception as e:
		return HttpResponse(json.dumps({"error":str(e)}),content_type='application/json')


def mainExecutionPolygon_Crime_EC_T_V_(polygon,lats,lngs):
	Aux        		= 	Crime_EC_T_V.objects.filter(point__within=polygon).only('codsetor','dateCrime','tipoCrime','coord_x','coord_y','codnode')
	ListCrimes  	= 	list(Aux)
	indicador 		= 	5
	Counting		=	Aux.values('tipoCrime').annotate(count=Count('tipoCrime')).order_by('count').reverse()
	elegidos 		= 	[]
	for arr in Counting:
		elegidos.append(arr['tipoCrime'])
	
	#get indicator 
	if (len(elegidos)>indicador):
		elegidos=elegidos[0:indicador]
	
	pointList=[]
	for i in range(len(lats)):
		pointList.append( geometry.Point(lats[i],lngs[i]))
	pointList.append( geometry.Point(lats[0],lngs[0]))
	poly = geometry.Polygon([[p.x, p.y] for p in pointList])

	try:
		pass
	except Exception as e:
		return HttpResponse(json.dumps({"error":str(e)}),content_type='application/json')

def mainExecutionPolygon_Crime_EC_T_V_(polygon,lats,lngs):
	Aux        	= Crime_EC_T_V.objects.filter(point__within=polygon).only('codsetor','dateCrime','tipoCrime','coord_x','coord_y','codnode')
	ListCrimes  = list(Aux)
	indicador = 5
	Counting=Aux.values('tipoCrime').annotate(count=Count('tipoCrime')).order_by('count').reverse()
	elegidos = []
	for arr in Counting:
		elegidos.append(arr['tipoCrime'])

	if (len(elegidos)>indicador):
		elegidos=elegidos[0:indicador]
	
	pointList=[]
	for i in range(len(lats)):
		pointList.append( geometry.Point(lats[i],lngs[i]))
	pointList.append( geometry.Point(lats[0],lngs[0]))
	poly = geometry.Polygon([[p.x, p.y] for p in pointList])

	try:
		G2  = ox.core.graph_from_polygon(poly,network_type='drive',simplify=False, retain_all=False, truncate_by_edge=True)
		G = G2.copy()
		G = ox.simplify_graph(G, strict=False)

		NodeDic={}
		for tp in list(G.nodes(data=True)):
			NodeDic[str(tp[0])]={'osmid':str(tp[1]['osmid']),'x':str(tp[1]['x']),'y':str(tp[1]['y']),'crime':0}

		resultado=[]
		for crime in ListCrimes:
			if(crime.tipoCrime in elegidos):
				try:
					NodeDic[str(crime.codnode)]['crime']+=1
				except:
					pass
				date 	= datetime.strptime(str(crime.dateCrime),formato_fecha)	#get crime date
				[nameMonth,nameDay,periodDay]=GetLabelofDate(date)
				resultado.append({'codnode':crime.codnode,'date':date.strftime("%d-%m-%Y %H:%M:%S"), 'crimeType':crime.tipoCrime,'codsetor':crime.codsetor,'labelMonth':nameMonth,'labelDay':nameDay,'labelPeriod':periodDay,'coord_x':crime.coord_x,'coord_y':crime.coord_y})
				#resultado.append({'codnode':crime.codnode, 'crimeType':crime.tipoCrime,'codsetor':crime.codsetor})

		EdgeList=[]
		for ed in list(G.edges(data=True)):
			if(NodeDic[str(ed[0])]['crime'] >=0 or NodeDic[str(ed[1])]['crime']>=0):
				if('geometry' in ed[2].keys()):
					midic={}
					midic['a']=ed[0]
					midic['b']=ed[1]
					#midic['geometry']=mapping((ed[2]['geometry']))
					inicio=Point(float(NodeDic[str(ed[0])]['x']),float(NodeDic[str(ed[0])]['y']))
					fin=Point(float(NodeDic[str(ed[1])]['x']),float(NodeDic[str(ed[1])]['y']))
					midic['geometry']=createGeometry(mapping((ed[2]['geometry'])),inicio,fin,NodeDic[str(ed[0])]['crime'],NodeDic[str(ed[1])]['crime'])
					midic['name']=''
					if ('name' in ed[2].keys()):
						midic['name']=ed[2]['name']
					EdgeList.append(midic)
		return HttpResponse(json.dumps({"Crimes":resultado,"EdgeList":EdgeList}),content_type='application/json')
	except Exception as e:
		return HttpResponse(json.dumps({"error":str(e)}),content_type='application/json')