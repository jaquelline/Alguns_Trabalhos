# -*- coding: utf-8 -*-
from django.contrib.gis.geos import GEOSGeometry,Point
import datetime
import calendar
from random import randrange
import pyproj
from functools import partial
from shapely.ops import transform

def GetPolygonWithArrays(array1,array2):
    poly='SRID=32140;POLYGON (('+str(array1[0])+' '+str(array2[0])
    for i in range(1,len(array1)):
        poly=poly+','+str(array1[i])+' '+str(array2[i])
    poly=poly+','+str(array1[0])+' '+str(array2[0])+'))'
    return poly

#labels
# name of Month
# name of day
# period of day
MONTHS_Portuguesse = ['Jan', 'Fev', 'Mar', 'Abr',  'Mai',  'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
MONTHS_English = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
Dict_Months = {'Jan':'Jan', 'Feb': 'Fev', 'Mar': 'Mar', 'Apr': 'Abr', 'May': 'Mai', 'Jun': 'Jun', 'Jul': 'Jul', 'Aug': 'Ago', 'Sep': 'Set', 'Oct': 'Out', 'Nov': 'Nov', 'Dec': 'Dez'}
Dict_Days 	= {'Mon':'Seg','Tue':'Ter','Wed':'Qua','Thu':'Qui','Fri':'Sex','Sat':'Sab','Sun':'Dom'}
def GetLabelofDate(dates):
	labelPeriod=""
	if 0<=dates.hour<6:
		labelPeriod = 'Mad'#"Dawn"
	elif 6<=dates.hour < 12:
		labelPeriod='Ama'#'Mor'
	elif 12 <= dates.hour < 18:
		labelPeriod= 'Tar' #'Aft'
	else:
		labelPeriod='Noi'#'Eve'
	return [Dict_Months[dates.strftime("%b")],Dict_Days[dates.strftime("%a")],labelPeriod]


def GetLabelofDate_(dates):
	labelPeriod=""
	if 0<=dates.hour<6:
		labelPeriod = 'Madrugada'#"Dawn"
	elif 6<=dates.hour < 12:
		labelPeriod='Amanhã'#'Mor'
	elif 12 <= dates.hour < 18:
		labelPeriod= 'Tarde' #'Aft'
	else:
		labelPeriod='Noite'#'Eve'
	return [dates.strftime("%b"),dates.strftime("%a"),labelPeriod]

def geodesic_point_buffer(lat, lon, dist):
	print(lat,lon,dist)
	proj_wgs_ = pyproj.Proj(init='epsg:4326')
	aeqd_proj = '+proj=aeqd +lat_0={lat} +lon_0={lon} +x_0=0 +y_0=0'
	project = partial(
        pyproj.transform,
        pyproj.Proj(aeqd_proj.format(lat=lat, lon=lon)),
        proj_wgs_)
	buf = Point(0, 0).buffer(dist)  # distance in metres
	return transform(project, buf).exterior.coords[:]