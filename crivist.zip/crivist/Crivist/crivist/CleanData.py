
import csv,sys,os
from django.contrib.gis.geos import GEOSGeometry,Point
from functools import partial
#from django.contrib.gis.geos import GEOSGeometry,Point
from shapely.geometry import Point,Polygon
from django.contrib.gis.geos import GEOSGeometry
from shapely.ops import transform
import pyproj
import numpy as np
from .models import Nodes,Edges,Second_Roubo,Crime_EC_T_V
from .utils import GetPolygonWithArrays
from shapely import geometry
from django.core.serializers import serialize

def geodesic_point_buffer(lat, lon, dist):
    # Azimuthal equidistant projection
    proj_wgs_ = pyproj.Proj(init='epsg:4326')
    aeqd_proj = '+proj=aeqd +lat_0={lat} +lon_0={lon} +x_0=0 +y_0=0'
    project = partial(
        pyproj.transform,
        pyproj.Proj(aeqd_proj.format(lat=lat, lon=lon)),
        proj_wgs_)
    buf = Point(0, 0).buffer(dist)  # distance in metres
    return transform(project, buf).exterior.coords[:]

Arreglo=[50,100,200,500,750,1000]

def te(lat, lng, i):
    pointCrime='SRID=32140;POINT('+lng+" "+lat+")"
    buffer =np.array(geodesic_point_buffer(float(lat),float(lng),Arreglo[i]))
    latitudes = buffer.T[1].tolist()
    longitudes = buffer.T[0].tolist()
    pos = GetPolygonWithArrays(longitudes,latitudes)
    polygon=GEOSGeometry(pos)
    MyNodes= list(Nodes.objects.filter(point__within=polygon).only('osmid','point'))
    if (len(MyNodes)==0):
        print("EN EL IF")
        if(i<len(Arreglo)-1):
            print(NodeSeleccionadoDef(lat, lng, i+1))
        else:
            print('')
    else:
        distancias=[]
        for nodoInd in MyNodes:
            distancias.append(GEOSGeometry(pointCrime).distance(GEOSGeometry(nodoInd.point))*100)
        index = distancias.index(min(distancias))
        NodoSelecionado =MyNodes[index].osmid
        print(NodoSelecionado)

def NodeSeleccionadoDef(lat, lng, i):
    pointCrime='SRID=32140;POINT('+lng+" "+lat+")"
    buffer =np.array(geodesic_point_buffer(float(lat),float(lng),Arreglo[i]))
    latitudes = buffer.T[1].tolist()
    longitudes = buffer.T[0].tolist()
    pos = GetPolygonWithArrays(longitudes,latitudes)
    polygon=GEOSGeometry(pos)
    MyNodes= list(Nodes.objects.filter(point__within=polygon).only('osmid','point'))
    if (len(MyNodes)==0):
        if(i<len(Arreglo)-1):
            return (NodeSeleccionadoDef(lat, lng, i+1))
        else:
            return ('')
    else:
        distancias=[]
        for nodoInd in MyNodes:
            distancias.append(GEOSGeometry(pointCrime).distance(GEOSGeometry(nodoInd.point))*100)
        index = distancias.index(min(distancias))
        NodoSelecionado =MyNodes[index].osmid
        return (NodoSelecionado)

def CleanRoubos():
    print("INICIANDO")
    path="D:\\Base_Roubo_Veiculo_2006_2017\\New\\"
    data=csv.reader(open(path+"PreProcessing_forGraph.csv"),delimiter=",")
    resposta=[]
    for row in data:
        lng = row[3]
        lat = row[4]
        NodeSeleccionado=NodeSeleccionadoDef(lat, lng, 0)
        '''pointCrime='SRID=32140;POINT('+row[3]+" "+row[4]+")"
        buffer =np.array(geodesic_point_buffer(lat,lng,50))
        lat = buffer.T[1].tolist()
        lon = buffer.T[0].tolist()
        pos = GetPolygonWithArrays(lat,lon)
        polygon=GEOSGeometry(pos)
        Nodes= list(Roubo_Crimes.objects.filter(point__within=polygon).only('osmid','point'))
        distancias=[]
        for nodo in nodes:
            distancias = pointCrime.distance(nodo.point)*100
        index = distancias.index(min(distancias))
        NodoSelecionado =Nodes[index].osmid'''
        resposta.append([row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],NodeSeleccionado])
    np.savetxt(path+"\\crimesWithNodes_Number.csv", np.array(resposta), fmt="%s", delimiter=',')
    print("TERMINE")

def CleanRoubos20016_2017():
    path ="D:\\NEV_DATA\\Base_Roubo_2006_2017\\"
    data=csv.reader(open(path+"routros6_17_CeMEAI_corregido_Final_coma.csv"),delimiter=",")
    resposta=[]
    for row in data:
        lng = row[9]
        lat = row[10]
        NodeSeleccionado=NodeSeleccionadoDef(lat, lng, 0)
        resposta.append([row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],NodeSeleccionado])
    np.savetxt(path+"\\routros6_17_CeMEAIWithNodes_Number.csv", np.array(resposta), fmt="%s", delimiter=',')
    print("Terminando")


def LOADDATA_CleanRoubos20016_2017():
    path ="D:\\NEV_DATA\\Base_Roubo_2006_2017\\"
    data=csv.reader(open(path+"routros6_17_CeMEAIWithNodes_Number.csv"),delimiter=",")
    resposta=[]
    print("COMENZO")
    for row in data:
        mycrime                 = Second_Roubo()
        mycrime.codsetor 		= row[7]
        mycrime.data			= row[2]
        mycrime.tipoCrime		= row[5]
        mycrime.station			= row[4]
        mycrime.coord_x			= row[8]
        mycrime.coord_y			= row[9]
        mycrime.point 			= 'SRID=32140;POINT('+row[8]+" "+row[9]+")"
        mycrime.codnode			= row[10]
        mycrime.save()
    print("TERMINE")


def CleanRoubosTranseunte2006_2017():
    path="D:\\NEV_DATA\\Base_Roubo_Transeuntes_2006_2017\\joined\\"
    data=csv.reader(open(path+"ALL_ROUBO_TRANSEUNTE_PreProcessing_forGraph.csv"),delimiter=",")
    resposta=[]
    dioerrado=[]
    i=0
    for row in data:
        try:
            lng = row[6].replace(',','.')
            lat = row[5].replace(',','.')
            NodeSeleccionado=NodeSeleccionadoDef(lat, lng, 0)
            resposta.append([row[1],row[2],row[3],row[4],lat,lng,row[7],row[8],NodeSeleccionado])
        except :
            dioerrado.append(i)
        i+=1
    np.savetxt(path+"\\TRANSEUNTE_crimesWithNodes_Number.csv", np.array(resposta), fmt="%s", delimiter=',')
    print("TERMINE")
    print("DIO ERRADO",dioerrado)

def CleanRoubosUncleanInstances():
    print("INICIANDO.............from")
    path="D:\\Base_Roubo_Veiculo_2006_2017\\"
    data=csv.reader(open(path+"UNCLEAN_crimesWithNodes_Number.csv"),delimiter=",")
    resposta=[]
    i=0
    for row in data:
        print(i)
        i+=1
        lng = row[3]
        lat = row[2]
        NodeSeleccionado=NodeSeleccionadoDef(lat, lng, 0)
        resposta.append([row[0],row[1],row[2],row[4],row[3],row[5],row[6],row[7],NodeSeleccionado])
    np.savetxt(path+"\\crimesWithNodes_Number_Unclear.csv", np.array(resposta), fmt="%s", delimiter=',')
    print("TERMINE........")

def CleanRoubosNumber():
    print("INICIANDO")
    path="D:\\Base_Roubo_Veiculo_2006_2017\\"
    data=csv.reader(open(path+"PreProcessing_forGraph.csv"),delimiter=",")
    resposta=[]
    i=0
    for row in data:
        print(i)
        lng = row[3]
        lat = row[4]
        NodeSeleccionado=NodeSeleccionadoDef(lat, lng, 0)
        resposta.append([row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],NodeSeleccionado])
        i+=1
        if(i>=100):
            break
    np.savetxt(path+"\\crimesWithNodes_Number.csv", np.array(resposta), fmt="%s", delimiter=',')
    print("TERMINE")
''' esto es valido pero no para servidor
import mpu.io
import json
from osgeo import ogr
def SavingPrimaryEdges():
    ListEdges = list(Edges.objects.filter(highway='primary'))
    EdgeList=[]
    for ed in ListEdges:
        midic={}
        midic['a']=ed.nfrom
        midic['b']=ed.nto
        midic['geometry']=str(ed.geom)
        midic['name']=''
        EdgeList.append(midic)
    mpu.io.write("D:\\pythonScripts\\graphs\\SaoPaulo_Dist_Primary.json", json.dumps(EdgeList))
'''

###################################################333


def CleanRoubosDRIVE_Ultimo():
    print("INICIANDO")
    Lista   =  Crime_EC_T_V.objects.filter(codnode = '')
    resposta=[]
    print("Ya tengo los datos")
    for ele in Lista:
        if(ele.codnode ==''):
            print(ele.id)
            try:
                lat = str(ele.coord_y)
                lng = str(ele.coord_x)
                NodeSeleccionado=NodeSeleccionadoDef(lat, lng, 0)
                ele.codnode = NodeSeleccionado
                ele.save()
            except:
                print(ele.id)
    '''for row in data:
        lng = row[3]
        lat = row[4]
        NodeSeleccionado=NodeSeleccionadoDef(lat, lng, 0)


        resposta.append([row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],NodeSeleccionado])
    np.savetxt(path+"\\crimesWithNodes_Number.csv", np.array(resposta), fmt="%s", delimiter=',')'''
    print("TERMINE")

def OtraTecnicaClosestNodes():
    Lista   =  Crime_EC_T_V.objects.filter(codnodeWalk = '')
    i =0
    print("INICIO ------------------")
    for ele in Lista:
        try:
            print(i)
            i+=1
            lat = ele.coord_y
            lng = ele.coord_x
            pointCrime='SRID=32140;POINT('+str(lng)+" "+str(lat)+")"
            buffer =np.array(geodesic_point_buffer(str(lat),str(lng),500))
            latitudes = buffer.T[1].tolist()
            longitudes = buffer.T[0].tolist()
            pos = GetPolygonWithArrays(longitudes,latitudes)
            
            polygon             = GEOSGeometry(pos)
            ListNodes        	= list(Nodes.objects.filter(point__within=polygon).only('point','osmid'))
            osmid = ''
            if (len(ListNodes)>0):
                distancias=[]
                for nodoInd in ListNodes:
                    distancias.append(GEOSGeometry(pointCrime).distance(GEOSGeometry(nodoInd.point))*100)
                index = distancias.index(min(distancias))
                osmid =ListNodes[index].osmid
            ele.codnodeWalk = osmid
            ele.save()
        except:
            pass
    print("TERMINE")


###################################################################################
###################FUNCION PARA CORREGIR ERRORES###################################
###################################################################################
import math
def CleanDataset():
    Lista   =  Crime_EC_T_V.objects.filter()
    i =0
    print("INICIO ------------------")
    for ele in Lista:
        integer = abs(math.modf(ele.coord_x)[1])
        if(integer==23):
            i+=1
            Aux = ele.coord_x
            ele.coord_x	= ele.coord_y 
            ele.coord_y	= Aux
            ele.point 	= 'SRID=32140;POINT('+str(ele.coord_x)+" "+str(ele.coord_y)+")"
            ele.codnodeWalk	= ''
            ele.save();  
    print("FINAL....")
    print("total:",str(i))
    
