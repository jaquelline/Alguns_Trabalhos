# -*- coding: utf-8 -*-
from django.db import models
from django.contrib.gis.db import models
from django.contrib.postgres.fields import JSONField
from django.contrib.gis.geos import GEOSGeometry,Point
# Create your models here.


class Roubo_Crimes(models.Model):
	codsetor 		= models.CharField(max_length=15)
	data			= models.DateTimeField() #%Y-%m-%d %H:%M:%S
	tipoCrime		= models.CharField(max_length=100)
	station			= models.CharField(max_length=50)
	coord_x			= models.FloatField()
	coord_y			= models.FloatField()
	point 			= models.PointField(srid=32140)
	codnode			= models.CharField(max_length=40)

	class Meta:
		db_table	= "Roubo_Crimes_0617"

class Second_Roubo(models.Model):
	codsetor 		= models.CharField(max_length=15)
	data			= models.DateTimeField() #%Y-%m-%d %H:%M:%S
	tipoCrime		= models.CharField(max_length=100)
	station			= models.CharField(max_length=50)
	coord_x			= models.FloatField()
	coord_y			= models.FloatField()
	point 			= models.PointField(srid=32140)
	codnode			= models.CharField(max_length=40)

class Crime_EC_T_V(models.Model):
	codsetor 		= models.CharField(max_length=20)
	dateCrime		= models.DateTimeField() #%Y-%m-%d %H:%M:%S
	tipoCrime		= models.CharField(max_length=100)
	coord_x			= models.FloatField()
	coord_y			= models.FloatField()
	point 			= models.PointField(srid=32140)
	codnode			= models.CharField(max_length=40)
	Geom			= models.CharField(max_length=10)
	codnodeWalk		= models.CharField(max_length=40,default='')

class Nodes(models.Model):
	osmid			= models.CharField(max_length=40)
	coord_x			= models.FloatField()
	coord_y			= models.FloatField()
	point 			= models.PointField(srid=32140)
	dist			= models.CharField(max_length=5)

class Edges(models.Model):
	name			= models.CharField(max_length=300)
	osmid			= models.CharField(max_length=150)
	nfrom			= models.CharField(max_length=80)
	nto				= models.CharField(max_length=80)
	geom 			= models.MultiLineStringField(srid=4326)
	highway			= models.CharField(max_length=80)

class ModeloCompacto(models.Model):
	name 			= models.CharField(max_length=87)
	osmid			= models.CharField(max_length=80)
	nfrom			= models.CharField(max_length=80)
	nto				= models.CharField(max_length=80)
	geom 			= models.MultiLineStringField(srid=4326)
	highway			= models.CharField(max_length=40)
	pointFrom		= models.PointField(srid=32140)
	pointTo			= models.PointField(srid=32140)

class DriveModeloCompacto(models.Model):
	name 			= models.CharField(max_length=100)
	osmid			= models.CharField(max_length=80)
	nfrom			= models.CharField(max_length=80)
	nto				= models.CharField(max_length=80)
	geom 			= models.MultiLineStringField(srid=4326)
	highway			= models.CharField(max_length=40)
	pointFrom		= models.PointField(srid=32140)
	pointTo			= models.PointField(srid=32140)

class WalkModeloCompacto(models.Model):
	name 			= models.CharField(max_length=300)
	osmid			= models.CharField(max_length=150)
	nfrom			= models.CharField(max_length=80)
	nto				= models.CharField(max_length=80)
	geom 			= models.MultiLineStringField(srid=4326)
	highway			= models.CharField(max_length=80)
	pointFrom		= models.PointField(srid=32140)
	pointTo			= models.PointField(srid=32140)